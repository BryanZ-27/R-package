#' One touch
#'
#' @param ID ID
#' @param database database
#' @param match match
#' @param mismatch mismatch
#' @param gap gap
#'
#' @return genbank files, fasta files and the result of global alignment
#' @export
#'
#' @examples none
one_touch <- function(ID, database, match, mismatch, gap){
  download_ncbi_gb(ID, database)
  gb_to_fasta(paste(sep = "", ID, ".gb"))
  fastafile <- paste(sep = "", ID, ".fasta")
  global_aln(fastafile[1], fastafile[2], match, mismatch, gap)
}