#' Download NCBI genbank file
#'
#' @param ID ID
#' @param database database
#'
#' @return genbank file
#' @export
#'
#' @examples none
download_ncbi_gb <- function(ID, database){
  options(warn = -1)
  url <- paste(sep = "", "https://www.ncbi.nlm.nih.gov/sviewer/viewer.cgi?tool=portal&save=file&log$=seqview&db=", database, "&report=genbank&id=", ID, "&conwithfeat=on&hide-cdd=on")
  download.file(url, destfile = paste(sep = "", ID, ".gb"), method = "libcurl")
  options(warn = 1)
}