#' Global alignment
#'
#' @param fastafile1 fastafile1 
#' @param fastafile2 fastafile2
#' @param match match
#' @param mismatch mismatch
#' @param gap gap
#'
#' @return the result of global alignment
#' @export
#'
#' @examples none
global_aln <- function(fastafile1, fastafile2, match, mismatch, gap){
  # deal with the fasta file
  options(warn = -1)
  fasta1 <- readLines(fastafile1)
  fasta2 <- readLines(fastafile2)
  accession1 <- gsub("[^a-zA-Z0-9].*", "", sub(">", "", fasta1[1]))
  accession2 <- gsub("[^a-zA-Z0-9].*", "", sub(">", "", fasta2[1]))
  x <- ""
  y <- ""
  for (i in 2:length(fasta1)){
    x <- paste(sep = "", x, fasta1[i])
  }
  for (i in 2:length(fasta2)){
    y <- paste(sep = "", y, fasta2[i])
  }
  # initialize the matrices
  colname <- strsplit(split = "", paste(sep = "", "-", x))
  rowname <- strsplit(split = "", paste(sep = "", "-", y))
  main <- matrix(nrow = length(rowname[[1]]), ncol = length(colname[[1]]), dimnames = list(rowname[[1]], colname[[1]]))
  index <- matrix(nrow = length(rowname[[1]]), ncol = length(colname[[1]]), dimnames = list(rowname[[1]], colname[[1]]))
  # fill the matrices
  for (i in 1:nrow(main)){
    for (j in 1:ncol(main)){
      if (rownames(main)[i] == colnames(main)[j]){
        match_score <- match
      }else{
        match_score <- mismatch
      }
      main[i, j] <- max(main[i - 1, j - 1] + match_score, main[i - 1, j] + gap, main[i, j - 1] + gap, na.rm = T)
      if (i == 1){
        index[i, j] <- 1
      }else if (j == 1){
        index[i, j] <- 3
      }else if (main[i - 1, j - 1] + match_score == main[i, j - 1] + gap && main[i - 1, j - 1] + match_score == main[i - 1, j] + gap){
        index[i, j] <- 7
      }else if (main[i - 1, j - 1] + match_score == main[i, j - 1] + gap && main[i - 1, j - 1] + match_score > main[i - 1, j] + gap){
        index[i, j] <- 4
      }else if (main[i - 1, j - 1] + match_score == main[i - 1, j] + gap && main[i - 1, j - 1] + match_score > main[i, j - 1] + gap){
        index[i, j] <- 5
      }else if (main[i, j - 1] + gap == main[i - 1, j] + gap && main[i, j - 1] + gap > main[i - 1, j - 1] + match_score){
        index[i, j] <- 6
      }else if (main[i - 1, j - 1] + match_score > main[i - 1, j] + gap && main[i - 1, j - 1] + match_score > main[i, j - 1] + gap){
        index[i, j] <- 2
      }else if (main[i - 1, j] + gap > main[i - 1, j - 1] + match_score && main[i - 1, j] + gap > main[i, j - 1] + gap){
        index[i, j] <- 3
      }else{
        index[i, j] <- 1
      }
      if (i == 1 && j == 1){
        main[i, j] <- index[i, j] <- 0
      }
    }
  }
  # trace back
  i <- nrow(main)
  j <- ncol(main)
  seq1 <- seq2 <- ""
  repeat {
    if (i == 1 && j == 1){
      break
    }
    if (index[i, j] == 2 || (index[i, j] == 4 && index[i - 1, j - 1] > index[i, j - 1]) || (index[i, j] == 5 && index[i - 1, j - 1] > index[i - 1, j]) || (index[i, j] == 7 && index[i - 1, j - 1] > index[i - 1, j] && index[i - 1, j - 1] > index[i, j - 1])){
      seq1 <- paste(sep = "", colnames(main)[j], seq1)
      seq2 <- paste(sep = "", rownames(main)[i], seq2)
      i <- i - 1
      j <- j - 1
    }else if (index[i, j] == 3 || (index[i, j] == 5 && index[i - 1, j] > index[i - 1, j - 1]) || (index[i, j] == 6 && index[i - 1, j] > index[i, j - 1]) || (index[i, j] == 7 && index[i - 1, j] > index[i - 1, j - 1] && index[i - 1, j] > index[i, j - 1])){
      seq1 <- paste(sep = "", "-", seq1)
      seq2 <- paste(sep = "", rownames(main)[i], seq2)
      i <- i - 1
    }else{
      seq2 <- paste(sep = "", "-", seq2)
      seq1 <- paste(sep = "", colnames(main)[j], seq1)
      j <- j - 1
    }
  }
  #caculate hamming distance
  distance <- 0
  aln_match <- ""
  for (i in 1:nchar(seq1)){
    if (substr(seq1, i, i) != substr(seq2, i, i)){
      distance <- distance + 1
    }
    if (substr(seq1, i, i) == "-" || substr(seq2, i, i) == "-"){
      aln_match <- paste(sep = "", aln_match, " ")
    }else{
      aln_match <- paste(sep = "", aln_match, "|")
    }
  }
  # generate the alignment results
  resultfile <- paste(sep = "", accession1, " and ", accession2, ".txt")
  cat("Scoring system: ", match, " for match; ", mismatch, " for mismatch; ", gap, " for gap\n\n", sep = "", file = resultfile)
  cat("Sequence ", accession1, ":\n", sep = "", file = resultfile, append = T)
  for (i in 1:ceiling(nchar(x) / 60)){
    cat(substr(x, (i - 1) * 60 + 1, i * 60), "\n", sep = "", file = resultfile, append = T)
  }
  cat("\nSequence ", accession2, ":\n", sep = "", file = resultfile, append = T)
  for (i in 1:ceiling(nchar(y) / 60)){
    cat(substr(y, (i - 1) * 60 + 1, i * 60), "\n", sep = "", file = resultfile, append = T)
  }
  cat("\nAlignment:\n", sep = "", append = T, file = resultfile)
  for (i in 1:ceiling(nchar(seq1) / 60)){
    cat(substr(seq1, (i - 1) * 60 + 1, i * 60), "\n", sep = "", file = resultfile, append = T)
    cat(substr(aln_match, (i - 1) * 60 + 1, i * 60), "\n", sep = "", file = resultfile, append = T)
    cat(substr(seq2, (i - 1) * 60 + 1, i * 60), "\n\n", sep = "", file = resultfile, append = T)
  }
  cat("Optimum alignment matrix: ", main[nrow(main), ncol(main)], sep = "", append = T, file = resultfile)
  cat("\n\nHamming distance: ", distance, sep = "", append = T, file = resultfile)
  options(warn = 1)
}