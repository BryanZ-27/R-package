#' Transform genbank file to fasta file
#'
#' @param files files
#'
#' @return fasta file
#' @export
#'
#' @examples none
gb_to_fasta <- function(files){
  for (i in 1:length(files)){
    genbank <- readLines(files[i])
    version <- genbank[startsWith(genbank, "VERSION")]
    version <- gsub("^VERSION\\s*", ">", version)
    definition <- genbank[which(startsWith(genbank, "DEFINITION")) : (which(startsWith(genbank, "ACCESSION")) - 1)]
    definition <- gsub("(^DEFINITION\\s)|(\\s+)", " ", definition)
    definition <- paste(sep = "", definition, collapse = "")
    head <- paste(sep = "", version, definition)
    head <- gsub("\\s+", " ", gsub("\\.$", "", head))
    seq <- genbank[which(startsWith(genbank, "ORIGIN")) : which(endsWith(genbank, "//"))]
    seq <- gsub("\\s|/*|[0-9]*", "", seq[-1])
    cat(head, toupper(seq[-length(seq)]), file = gsub("gb", "fasta", files[i]), sep = "\n")
  }
}